jQuery(document).ready(function () {
  $(window).scroll(function () {
    if ($(document).scrollTop() > 300) {
      $(".header_wrap").addClass("header_active");
    } else {
      $(".header_wrap").removeClass("header_active");
    }
  });
});
